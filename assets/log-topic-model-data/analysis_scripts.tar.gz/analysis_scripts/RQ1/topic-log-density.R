# analyze each topic's log density

require(glmnet) # for LASSO
require(ROSE) # for AUC
require(ROCR) # for AUC
require(caret) # for upSample and downSample, and n-fold cross-validation
require(textir) # tf-idf
require(e1071) # for skewness

project <- "hadoop"
num_topics <- 500

#######################################################################
##            Loading data and preprocessing data                    ##
#######################################################################

## doc-topics
doc_topics <- read.csv(paste("doc_topics_", num_topics, ".csv", sep=""))
# filter noises
filter_threshold <- 0.01
doc_topics[, sapply(doc_topics, is.numeric)][doc_topics[, sapply(doc_topics, is.numeric)] < filter_threshold] <- 0

## doc-logs
doc_logs <- read.csv("remaining_methods.csv")
# remove duplicated method names
duplicated_names <- doc_logs[duplicated(doc_logs$method), "method"]
if (length(duplicated_names) > 0) {
  doc_logs <- doc_logs[-which(doc_logs$method %in% duplicated_names), ]
}

## merge data
doc_logs_topics <- merge(doc_logs, doc_topics, 
                         by.x="method", by.y="fileName")



## log density and other statistics for each topic
topics <- sapply(c(0:(num_topics-1)), function(x) return(paste("T", x, sep="")))

topics_cum_logden <- sapply(topics, 
                            function(topic) sum(doc_logs_topics[, topic] * 
                                                  doc_logs_topics$lognum / 
                                                  doc_logs_topics$loc))

topics_scaled_logden <- sapply(topics, 
                               function(topic) sum(doc_logs_topics[, topic] * doc_logs_topics$lognum) / sum(doc_logs_topics[, topic] * doc_logs_topics$loc))

topics_docnum <- sapply(topics, 
                        function(topic) sum(doc_logs_topics[, topic] > 0))
topics_logged_docnum <- sapply(topics, 
                               function(topic) sum(doc_logs_topics[, topic] > 0 &
                                                     doc_logs_topics$lognum > 0))

topics_log_stat <- data.frame(Topic=topics, 
                              ScaledLogDensity=topics_scaled_logden,
                              CumLogDensity=topics_cum_logden,
                              DocNum = topics_docnum,
                              LoggedDocNum = topics_logged_docnum)

topics_by_scaled_logden <- topics_log_stat[order(topics_log_stat$ScaledLogDensity, decreasing=TRUE),]
topics_by_cum_logden <- topics_log_stat[order(topics_log_stat$CumLogDensity, decreasing=TRUE),]
 
top_topics <- intersect(topics_by_scaled_logden$Topic[1:25], 
                        topics_by_cum_logden$Topic[1:25])

top_topics <- topics_log_stat[topics_log_stat$Topic %in% top_topics, ]
top_topics <- top_topics[order(top_topics$ScaledLogDensity, decreasing=TRUE), ]

## summarize scaled log density for each project
stats_0 <- as.vector(summary(topics_scaled_logden))
skew <- skewness(topics_scaled_logden)
topics_scaled_logden_summary <- 
  data.frame(project, stats_0[1], stats_0[2], 
             stats_0[3], stats_0[5], stats_0[6],
                        skew)
names(topics_scaled_logden_summary) <- 
  c("Project", "Min", "1st Qu.", "Median", "3rd Qu.", "Max.", "Skewness")
row.names(topics_scaled_logden_summary) <- NULL
topics_scaled_logden_summary

## summarize cumulative log density for each project
stats_0 <- as.vector(summary(topics_cum_logden))
skew <- skewness(topics_cum_logden)
topics_cum_logden_summary <- 
  data.frame(project, stats_0[1], stats_0[2], 
             stats_0[3], stats_0[5], stats_0[6],
             skew)
names(topics_cum_logden_summary) <- 
  c("Project", "Min", "1st Qu.", "Median", "3rd Qu.", "Max.", "Skewness")
row.names(topics_cum_logden_summary) <- NULL
topics_cum_logden_summary


## print the top topics
topic_keys <- read.csv(paste("topic_keys_", num_topics, ".dat", sep=""), header = FALSE, sep="")
names(topic_keys) <- c("Topic", "Dirichlet", sapply(c(1:20), function(x) paste("K", x, sep="")))
topic_keys$Topic <- paste("T", topic_keys$Topic, sep="")

top_topics_keys <- merge(top_topics, topic_keys, by="Topic")
top_topics_keys <- top_topics_keys[order(top_topics_keys$ScaledLogDensity, decreasing = TRUE),]
write.csv(top_topics_keys, paste("top_topics_keys_", num_topics, ".csv", sep=""), row.names = FALSE, quote = FALSE)

save.image(paste("topic-log-density-", num_topics, ".RData", sep=""))
