# analyze topics of methods and logs of methods
wants <- c("glmnet", "ROCR", "caret", "textir", "doMC", "doParallel", "e1071")
has   <- wants %in% rownames(installed.packages())
if(any(!has)) install.packages(wants[!has], repos="http://cran.utstat.utoronto.ca")

require(glmnet) # for LASSO
require(ROCR) # for AUC
require(caret) # for upSample and downSample, and n-fold cross-validation
require(textir) # tf-idf
require(e1071)

# parallel setting for linux
require(doMC)
registerDoMC(cores=8)

# parallel setting for windows
#require(doParallel)
#registerDoParallel(cores=4)

num_topics <- 500

#######################################################################
##            Loading data and preprocessing data                    ##
#######################################################################

## doc-topics
doc_topics <- read.csv(paste("doc_topics_", num_topics, ".csv", sep=""))
# filter noises
doc_topics[, sapply(doc_topics, is.numeric)][doc_topics[, sapply(doc_topics, is.numeric)] < 0.01] <- 0

## doc-logs
doc_logs <- read.csv("remaining_methods.csv")
# remove duplicated method names
duplicated_names <- doc_logs[duplicated(doc_logs$method), "method"]
if (length(duplicated_names) > 0) {
  doc_logs <- doc_logs[-which(doc_logs$method %in% duplicated_names), ]
}

## doc-metrics about control flow statements
doc_metrics <- read.csv("base_metrics.csv")
# remove duplicated method names
duplicated_names2 <- doc_metrics[duplicated(doc_metrics$method), "method"]
if (length(duplicated_names2) > 0) {
  doc_metrics <- doc_metrics[-which(doc_metrics$method %in% duplicated_names2), ]
}
doc_metrics$ifnull <- NULL

## merge data
doc_logs_metrics <- merge(doc_logs, doc_metrics, by="method")

doc_logs_metrics_topics <- merge(doc_logs_metrics,doc_topics, 
                                 by.x="method", by.y="fileName")

## our DATA
data <- doc_logs_metrics_topics

# remove zero variance columns
zero_vars <- names(data)[sapply(data, function(x) length(unique(x)) == 1)]
data <- data[, !(names(data) %in% zero_vars)]

# remove unnessary data to save the memory
rm(doc_logs, doc_metrics, doc_topics)
rm(doc_logs_metrics, doc_logs_metrics_topics)

## resposne variable
response <- "lognum"

## explanatory variables
expl_base <- c("loc", "try", "catch", "throw", "throws", "if.", "else.", "switch", 
               "for.", "while.", "return", "methodcall", "fanin")
expl_base <- expl_base[expl_base %in% names(data)]
expl_topics <- sapply(c(0:(num_topics-1)), function(x) return(paste("T", x, sep="")))
expl_topics <- expl_topics[expl_topics %in% names(data)]
expl_base_topics <- c(expl_base, expl_topics)

## make the response variable (lognum) a bianry factor
data[, response] <- as.factor(data[, response] > 0)


#######################################################################
##################### Scale the data ##################################
# scale the numeric columns to be with mean value 0 and standard deviation 1
# (Relative Importance Analysis through standarized regression coefficients)
data[, sapply(data, is.numeric)] <- scale(data[, sapply(data, is.numeric)])

#######################################################################
##################### pre-process the data ############################
#data_expl <- data[, expl]
#trans <- preProcess(data_expl, method=c("BoxCox", "center", "scale"))
#data_expl <- predict(trans, data_expl)
#data[, expl] <- data_expl

# na predictors
na_vars <- expl[sapply(data[, expl], function(one_col) any(is.na(one_col)))]
data <- data[, !(colnames(data) %in% na_vars)]

# update variable sets after removing variables
expl_base <- expl_base[!(expl_base %in% na_vars)]
expl_topics <- expl_topics[!(expl_topics %in% na_vars)]
expl_base_topics <- expl_base_topics[!(expl_base_topics %in% na_vars)]
expl <- expl_base_topics


#######################################################################
##                   Modeling analysis using lasso                   ##
#######################################################################

## data splitting
set.seed(11)
trainIndex = createDataPartition(data[, response], p = 0.8, list=FALSE, times = 1)
testset = data[-trainIndex,]
trainset = data[trainIndex,]


# function to train, tune, and evaluate the lasso model 
# use 10-fold cross-validation to tune the lambda hyper-parameter

train_tune_evaluate_lasso_model <- function(response, predictors, trainset, testset)
{
  # weight of each instance
  n_true <- sum(as.logical(trainset[, response]) == TRUE)
  n_false <- sum(as.logical(trainset[, response]) == FALSE)
  ratio <- n_false / n_true
  weights <- rep(1, nrow(trainset))
  weights[as.logical(trainset[, response])==TRUE] <- ratio
  
  # use iterations of 10-fold cross-validation to tune the lambda value
  set.seed(111)
  cv.lasso <- cv.glmnet(x = as.matrix(trainset[, predictors]), 
                        y = trainset[, response],
                        family = 'binomial', 
                        nfolds = 10, 
                        type.measure = "auc",
                        weights = weights,
                        standardize = TRUE, 
                        alpha = 1.0,
                        parallel=TRUE) 
  
  glmnet.fit <- cv.lasso$glmnet.fit
  devratio <- glmnet.fit$dev.ratio[which(glmnet.fit$lambda==cv.lasso$lambda.min)] 
  
  predicted.class <- predict(cv.lasso, 
                             newx = as.matrix(testset[, predictors]), 
                             s = "lambda.1se",
                             type = "class")
  
  predicted.prob <- predict(cv.lasso, 
                            newx = as.matrix(testset[, predictors]), 
                            s = "lambda.1se",
                            type = "response")
  
  predicted.coefs <- predict(cv.lasso, 
                             newx = as.matrix(testset[, predictors]), 
                             s = "lambda.1se",
                             type = "coefficients")
  
  TP <- sum((as.logical(predicted.class)==TRUE) & (as.logical(testset[, response])==TRUE))
  TN <- sum((as.logical(predicted.class)==FALSE) & (as.logical(testset[, response])==FALSE))
  FP <- sum((as.logical(predicted.class)==TRUE) & (as.logical(testset[, response])==FALSE))
  FN <- sum((as.logical(predicted.class)==FALSE) & (as.logical(testset[, response])==TRUE))
  
  precision <- TP / (TP + FP)
  recall <- TP / (TP + FN)
  ba <- 1/2 * (TP/(TP+FN)) + 1/2 * (TN/(TN+FP))
  
  pred <- prediction(predicted.prob, testset[, response])
  auc <- performance(pred,"auc")
  auc <- unlist(slot(auc, "y.values"))
  
  ## coefficients
  coefs <- as.matrix(predicted.coefs)
  nonzero_coefs <- rownames(coefs)[coefs != 0]
  nonzero_metrics_num <- length(nonzero_coefs) - 1 # minus the intercept
  topic_metrics <- nonzero_coefs[grepl("T\\d", nonzero_coefs, fixed=FALSE)]
  nonzero_topic_metrics_num <- length(topic_metrics)
  word_metrics <- nonzero_coefs[grepl("word_", nonzero_coefs, fixed=TRUE)]
  nonzero_word_metrics_num <- length(word_metrics)
  nonzero_base_metrics_num <- nonzero_metrics_num - nonzero_topic_metrics_num - nonzero_word_metrics_num
  
  coefs_df <- data.frame(metric=rownames(coefs), coef=as.vector(coefs))
  coefs_df <- coefs_df[coefs_df$metric != "(Intercept)", ]
  coefs_df <- coefs_df[order(abs(coefs_df$coef), decreasing = TRUE),]
  #write.csv(coefs_df, "coefs_all.csv", row.names=FALSE)
  coefs_topics <- data.frame(metric=rownames(coefs)[rownames(coefs) %in% topic_metrics],
                             coef=coefs[rownames(coefs) %in% topic_metrics])
  coefs_topics <- coefs_topics[order(abs(coefs_topics$coef), decreasing = TRUE),]
  #write.csv(coefs_topics, "coefs_topics.csv", row.names=FALSE)
  coefs_words <- data.frame(metric=rownames(coefs)[rownames(coefs) %in% word_metrics],
                            coef=coefs[rownames(coefs) %in% word_metrics])
  coefs_words <- coefs_words[order(abs(coefs_words$coef), decreasing = TRUE),]
  #write.csv(coefs_words, "coefs_words.csv", row.names=FALSE)
  
  
  print("Balanced accuracy:")
  print(ba)
  print("AUC: ")
  print(auc)
  print("Dev ratio:")
  print(devratio)
  
  return(list(precision=precision, recall=recall, ba=ba,
              auc=auc, devratio=devratio, cv.lasso=cv.lasso, 
              coefs.unsorted=coefs, coefs.nonzeronum=nonzero_metrics_num,
              coefs.all=coefs_df, coefs.topics=coefs_topics, coefs.words=coefs_words))

}

eval.base <- train_tune_evaluate_lasso_model(response, expl_base, trainset, testset)
eval.base_topics <- train_tune_evaluate_lasso_model(response, expl_base_topics, trainset, testset)

save.image(paste("log_topic_model_", num_topics, "_topics.RData", sep=""))

