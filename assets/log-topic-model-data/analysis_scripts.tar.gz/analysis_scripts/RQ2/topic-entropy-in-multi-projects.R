# analyze each topic's log density

require(glmnet) # for LASSO
require(ROSE) # for AUC
require(ROCR) # for AUC
require(caret) # for upSample and downSample, and n-fold cross-validation
require(textir) # tf-idf
require(xtable)
require(e1071) # for skewness

num_topics <- 3000
top_LD_th <- 300

#######################################################################
##            Loading data and preprocessing data                    ##
#######################################################################

## doc-topics
doc_topics <- read.csv("doc_topics.csv")

# parse project names and file names
doc_topics$fileName <- as.character(doc_topics$fileName)
fileNames <- sub(".*/combined_preprocessed_data/(hadoop|directory-server|qpid-java|cloudstack|camel|airavata)/(.*)",
                 "\\2",
                 doc_topics$fileName)
projectNames <- sub(".*/combined_preprocessed_data/(hadoop|directory-server|qpid-java|cloudstack|camel|airavata)/(.*)",
                 "\\1",
                 doc_topics$fileName)

doc_topics$fileName <- fileNames
doc_topics$project <- projectNames
# filter noises
doc_topics[, sapply(doc_topics, is.numeric)][doc_topics[, sapply(doc_topics, is.numeric)] < 0.01] <- 0

## doc-logs

project_list <- c("hadoop", "directory-server", "qpid-java", "camel", "cloudstack", "airavata")

# read in data for each project
combo_data <- c()
for (project in project_list) {
  print(project)
  data_file <- paste(project, "_remaining_methods.csv", sep="")
  project_data <- read.csv(data_file, header=TRUE, sep=",")
  project_data$project <- project
  combo_data <- rbind(combo_data, project_data)
  #break
}

#doc_logs <- read.csv("remaining_methods.csv")
doc_logs <- combo_data
# remove duplicated method names
duplicated_names <- doc_logs[duplicated(doc_logs$method), "method"]
if (length(duplicated_names) > 0) {
  doc_logs <- doc_logs[-which(doc_logs$method %in% duplicated_names), ]
}

## merge data
doc_logs_topics <- merge(doc_logs, doc_topics, 
                         by.x=c("project", "method"), 
                         by.y=c("project", "fileName"))


## log density and other statistics for each topic
topics <- sapply(c(0:(num_topics-1)), function(x) return(paste("T", x, sep="")))

topics_cum_logden <- sapply(topics, 
                            function(topic) sum(doc_logs_topics[, topic] * 
                                                  doc_logs_topics$lognum / 
                                                  doc_logs_topics$loc))

topics_scaled_logden <- sapply(topics, 
                               function(topic) sum(doc_logs_topics[, topic] * doc_logs_topics$lognum) / sum(doc_logs_topics[, topic] * doc_logs_topics$loc))
topics_docnum <- sapply(topics, 
                        function(topic) sum(doc_logs_topics[, topic] > 0))
topics_logged_docnum <- sapply(topics, 
                               function(topic) sum(doc_logs_topics[, topic] > 0 &
                                                     doc_logs_topics$lognum > 0))

## general function for calculating the normalized entropy for a vector of probabilties
computeEntropy <- function(data){
    data.norm <- data + 0.00000001 # To avoid taking log of 0; doesn't affect results
    data.norm <- data.norm/sum(data.norm) # Make sure data sums to 1
    ent <- -sum((log2(data.norm)*data.norm)) # Actual computation
    ent/log2(length(data)) # Normalize by the log of the length of the incoming vector
}

## aggregated probability of each topic in each project: each row is a project, each column is a topic
project_topic <- data.frame(matrix(ncol=num_topics, nrow=length(project_list)))
rownames(project_topic) <- project_list
colnames(project_topic) <- topics
for (project in project_list) {
    project_topic[project, ] <- sapply(topics, 
                                       function(topic) sum(doc_logs_topics[doc_logs_topics$lognum > 0 &
                                                                           doc_logs_topics$project == project,
                                                                           topic]) /
                                         sum(doc_logs_topics$project == project))
}
 
## entropy of each topic
topics_ent <- sapply(topics, function(topic) computeEntropy(project_topic[, topic]))
#topics_ent <- sapply(topics, function(topic) computeEntropy(doc_logs_topics[, topic]))   

topics_log_stat <- data.frame(Topic=topics, 
                              ScaledLogDensity=topics_scaled_logden,
                              CumLogDensity=topics_cum_logden,
                              DocNum = topics_docnum,
                              LoggedDocNum = topics_logged_docnum,
                              Entropy = topics_ent)

topics_by_scaled_logden <- topics_log_stat[order(topics_log_stat$ScaledLogDensity, decreasing=TRUE),]
topics_by_cum_logden <- topics_log_stat[order(topics_log_stat$CumLogDensity, decreasing=TRUE),]

top_topics <- intersect(topics_by_scaled_logden$Topic[1:top_LD_th], 
                         topics_by_cum_logden$Topic[1:top_LD_th])

top_topics <- topics_log_stat[topics_log_stat$Topic %in% top_topics, ]
##top_topics <- top_topics[order(top_topics$ScaledLogDensity, decreasing=TRUE), ]
top_topics <- top_topics[order(top_topics$Entropy, decreasing=TRUE), ]


## summarize topic entropy in projects
stats_0 <- as.vector(summary(topics_ent))
skew <- skewness(topics_ent)
topics_ent_summary <- 
  data.frame(stats_0[1], stats_0[2], 
             stats_0[3], stats_0[5], stats_0[6],
             skew)
names(topics_ent_summary) <- 
  c("Min", "1st Qu.", "Median", "3rd Qu.", "Max.", "Skewness")
row.names(topics_ent_summary) <- NULL
topics_ent_summary


## tablize summary of entropy
print(xtable(topics_ent_summary), include.rownames=FALSE)

## summarize top-topic entropy in projects
top_topics_ent <- top_topics$Entropy
print(top_topics_ent)
print(length(top_topics_ent))
stats_0 <- as.vector(summary(top_topics_ent))
skew <- skewness(top_topics_ent)
top_topics_ent_summary <- 
  data.frame(stats_0[1], stats_0[2], 
             stats_0[3], stats_0[5], stats_0[6],
             skew)
names(top_topics_ent_summary) <- 
  c("Min", "1st Qu.", "Median", "3rd Qu.", "Max.", "Skewness")
row.names(top_topics_ent_summary) <- NULL
top_topics_ent_summary


## tablize summary of log density
#print(xtable(topics_scaled_logden_summary), include.rownames=FALSE)
#print(xtable(topics_cum_logden_summary), include.rownames=FALSE)
print(xtable(top_topics_ent_summary), include.rownames=FALSE)



## visualize entropy for top log-intensive topics
#top_topics$Entropy
require(ggplot2)
ggplot(top_topics, aes(x=Entropy)) + 
  geom_histogram(binwidth=0.1, fill="white", colour="black") +
  stat_bin(binwidth = 0.1, geom="text", aes(label=..count..), vjust=-0.4) +
  #xlim(0, 1) + 
  ylim(0,8.5) + 
  xlab("Topic Entropy") + ylab("Topic Count") +
  scale_x_continuous(breaks=c(0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0),
                     limits=c(0, 1))
ggsave("EntropyHistogram.pdf", width=16, heigh=8, unit="cm")

skewness(top_topics$Entropy)


